Command to build all files
/------------------------------------/
make

Commands to run program
/-----------------------------------/
make run (run automatically)

Command to delete files created by make
/------------------------------------/
make clean

Command to kill all processes
/-------------------------------------/
make killall

Instructions
/--------------------------------------/
1. Build all of the files
2. Run the program
